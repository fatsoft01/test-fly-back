ls > ken.out
cat ken.dat > ken2.dat

